import kotlin.random.Random

fun main(args: Array<String>) {
    val x = Random.nextDouble(0.0,1.0)
    println(x)
}