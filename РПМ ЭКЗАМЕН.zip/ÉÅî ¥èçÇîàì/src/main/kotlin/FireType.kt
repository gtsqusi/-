sealed class FireType
object Single: FireType()
object Burst: FireType()